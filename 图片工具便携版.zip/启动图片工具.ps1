# 图片工具启动脚本
Write-Host "正在启动图片工具..." -ForegroundColor Green
Start-Process -FilePath "图片工具.exe"
